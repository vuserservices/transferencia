import pandas as pd

df = pd.read_pickle('./robot4.pkl')

print(df)
